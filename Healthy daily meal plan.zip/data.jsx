// Histamine-friendly meal library + 7-day week plan

// ─────────────────────────────────────────────────────────────
// Meal library — keyed by id
// ─────────────────────────────────────────────────────────────
const MEALS = {
  // ── Raňajky ───────────────────────────────────────────────
  'r-ovs': {
    id: 'r-ovs', type: 'Raňajky', time: '8:00', img: 'oats',
    title: 'Ovsená kaša s čučoriedkami',
    sub: 'mandle · jablko · škorica', minutes: 10, score: 'low',
    ingredients: [
      { name: 'Ovsené vločky (jemné)', qty: '60 g' },
      { name: 'Ryžový nápoj', qty: '250 ml' },
      { name: 'Čerstvé čučoriedky', qty: '80 g' },
      { name: 'Strúhané jablko', qty: '½ ks' },
      { name: 'Mandle, plátkové', qty: '15 g' },
      { name: 'Mletá škorica', qty: 'štipka' },
      { name: 'Javorový sirup', qty: '1 lyž.' },
    ],
    steps: [
      'Ryžový nápoj priveď k miernemu varu.',
      'Pridaj vločky a za stáleho miešania var 4–5 minút.',
      'Vmiešaj strúhané jablko a štipku škorice.',
      'Preroz do misky, ozdob čučoriedkami a mandľami.',
      'Pokvapkaj javorovým sirupom. Konzumuj čerstvé.',
    ],
    note: 'Vločky a čerstvé bobuľoviny sú jeden z najlepších ranných štartérov. Žiadne zrejúce ani kvasené zložky.',
  },
  'r-ryza': {
    id: 'r-ryza', type: 'Raňajky', time: '8:00', img: 'rice',
    title: 'Ryžová kaša s mangom',
    sub: 'kokosové mlieko · vanilka', minutes: 18, score: 'low',
    ingredients: [
      { name: 'Ryža okrúhlozrnná', qty: '60 g' },
      { name: 'Kokosové mlieko (čerstvé otvorené)', qty: '200 ml' },
      { name: 'Voda', qty: '100 ml' },
      { name: 'Čerstvé mango', qty: '½ ks' },
      { name: 'Vanilkový struk', qty: '½' },
      { name: 'Javorový sirup', qty: '1 lyž.' },
    ],
    steps: [
      'Ryžu prepláchni a daj variť do zmesi vody a kokosového mlieka.',
      'Pridaj rozkrojený vanilkový struk, var na miernom 15 min.',
      'Mango nakrájaj na kocky.',
      'Kašu polej sirupom a doplň mangom. Konzumuj hneď.',
    ],
    note: 'Otvorené kokosové mlieko spotrebuj v ten istý deň — po fermentácii rýchlo rastie histamín.',
  },
  'r-omel': {
    id: 'r-omel', type: 'Raňajky', time: '8:00', img: 'chicken',
    title: 'Omeleta s cuketou a bylinkami',
    sub: '2 vajcia · petržlen · pažítka', minutes: 12, score: 'low',
    ingredients: [
      { name: 'Vajcia (čerstvé)', qty: '2 ks' },
      { name: 'Cuketa', qty: '½ menšej' },
      { name: 'Maslo', qty: '1 lyž.' },
      { name: 'Pažítka, petržlen', qty: 'hrsť' },
      { name: 'Soľ', qty: 'štipka' },
    ],
    steps: [
      'Cuketu nakrájaj na tenké plátky, krátko opraž na masle.',
      'Vajcia rozšľahaj so štipkou soli.',
      'Zalej cuketu a smaž 3 min, prevráť a dokonči.',
      'Posyp bylinkami a podávaj.',
    ],
    note: 'Vajcia v žltku histamín neuvoľňujú, bielok je iba mierny uvoľňovač — dobre tolerované, ak ho neješ denne.',
  },
  'r-quin': {
    id: 'r-quin', type: 'Raňajky', time: '8:00', img: 'oats',
    title: 'Quinoa kaša s hruškou',
    sub: 'mandľové mlieko · kardamóm', minutes: 20, score: 'low',
    ingredients: [
      { name: 'Quinoa', qty: '50 g' },
      { name: 'Mandľové mlieko (čerstvé)', qty: '250 ml' },
      { name: 'Hruška', qty: '1 ks' },
      { name: 'Mletý kardamóm', qty: 'štipka' },
      { name: 'Med', qty: '1 lyž.' },
    ],
    steps: [
      'Quinou prepláchni studenou vodou.',
      'Var v mandľovom mlieku 15–18 minút do mäkka.',
      'Hrušku nakrájaj na plátky, vmiešaj kardamóm.',
      'Servíruj s medom a hruškou.',
    ],
    note: 'Quinoa je bez lepku a histamínovo veľmi neutrálna — výborný diverzifikátor.',
  },
  'r-poh': {
    id: 'r-poh', type: 'Raňajky', time: '8:00', img: 'oats',
    title: 'Pohánková kaša s pečeným jablkom',
    sub: 'orechové maslo · vlaš­ské semiačka', minutes: 22, score: 'low',
    ingredients: [
      { name: 'Pohánkové krúpy', qty: '60 g' },
      { name: 'Ryžový nápoj', qty: '250 ml' },
      { name: 'Jablko', qty: '1 ks' },
      { name: 'Maslo', qty: '½ lyž.' },
      { name: 'Mletá škorica', qty: 'štipka' },
    ],
    steps: [
      'Jablko rozkroj, daj piecť na 180°C s kúskom masla, 12 min.',
      'Pohánku vyvar v ryžovom nápoji 15 minút.',
      'Spoj v miske, posyp škoricou.',
    ],
    note: 'Pohánka je výborná alternatíva k ovsu pri streetových intoleranciách.',
  },
  'r-kuk': {
    id: 'r-kuk', type: 'Raňajky', time: '8:00', img: 'oats',
    title: 'Kukuričná kaša s broskyňou',
    sub: 'polenta · med', minutes: 15, score: 'low',
    ingredients: [
      { name: 'Jemná polenta', qty: '50 g' },
      { name: 'Ryžový nápoj', qty: '300 ml' },
      { name: 'Čerstvá broskyňa', qty: '1 ks' },
      { name: 'Med', qty: '1 lyž.' },
      { name: 'Maslo', qty: '1 lyž.' },
    ],
    steps: [
      'Ryžový nápoj priveď k varu, pomaly vsyp polentu.',
      'Vari 8 min, miešaj. Vmiešaj maslo.',
      'Servíruj s nakrájanou broskyňou a medom.',
    ],
    note: 'Broskyne a marhule sú nízkohistamínové, ak sú v sezóne a zrelé — vyhnúť sa konzervovaným.',
  },
  'r-aman': {
    id: 'r-aman', type: 'Raňajky', time: '8:00', img: 'rice',
    title: 'Amarant s pečenými figami',
    sub: 'med · mandľové vločky', minutes: 22, score: 'low',
    ingredients: [
      { name: 'Amarant', qty: '50 g' },
      { name: 'Voda', qty: '200 ml' },
      { name: 'Čerstvé figy', qty: '2 ks' },
      { name: 'Mandľové plátky', qty: '15 g' },
      { name: 'Med', qty: '1 lyž.' },
    ],
    steps: [
      'Amarant uvar 18 min v osolenej vode.',
      'Figy rozkroj a krátko opeč na panvici.',
      'Servíruj s mandľami a medom.',
    ],
    note: 'Čerstvé figy (nie sušené!) sú dobre znášané. Sušené sú často sírené.',
  },

  // ── Obedy ─────────────────────────────────────────────────
  'o-kura': {
    id: 'o-kura', type: 'Obed', time: '13:00', img: 'chicken',
    title: 'Kuracie prsia s ryžou a cuketou',
    sub: 'olivový olej · petržlen', minutes: 25, score: 'low',
    ingredients: [
      { name: 'Kuracie prsia (čerstvé)', qty: '150 g' },
      { name: 'Basmati ryža', qty: '70 g' },
      { name: 'Cuketa', qty: '1 menšia' },
      { name: 'Olivový olej', qty: '2 lyž.' },
      { name: 'Petržlenová vňať', qty: 'hrsť' },
    ],
    steps: [
      'Ryžu uvar v osolenej vode podľa návodu.',
      'Kuracie prsia nakrájaj, jemne osoľ, opekaj 3–4 min z každej strany.',
      'Cuketu poduste na zvyšnom oleji do mäkka.',
      'Servíruj okamžite s čerstvým petržlenom.',
    ],
    note: 'Mäso musí byť čerstvé — najlepšie spotrebované v deň nákupu.',
  },
  'o-mor': {
    id: 'o-mor', type: 'Obed', time: '13:00', img: 'chicken',
    title: 'Morčacie kúsky s quinoa a brokolicou',
    sub: 'zázvor · čerstvý petržlen', minutes: 28, score: 'low',
    ingredients: [
      { name: 'Morčacie prsia (čerstvé)', qty: '150 g' },
      { name: 'Quinoa', qty: '70 g' },
      { name: 'Brokolica', qty: '200 g' },
      { name: 'Olivový olej', qty: '2 lyž.' },
      { name: 'Zázvor, čerstvý', qty: '1 cm' },
    ],
    steps: [
      'Quinou prepláchni a uvar v osolenej vode 15 min.',
      'Morčacie nakrájaj na kocky, opeč s nastrúhaným zázvorom.',
      'Brokolicu blanšíruj 4 min, pridaj k mäsu.',
      'Spoj všetko s quinou, pokvapkaj olivovým olejom.',
    ],
    note: 'Morčacie je dobrou alternatívou k stále kuraciemu. Zázvor pôsobí protihistamínovo.',
  },
  'o-tela': {
    id: 'o-tela', type: 'Obed', time: '13:00', img: 'chicken',
    title: 'Pečené teľacie s mrkvou a zemiakmi',
    sub: 'olej · čerstvý rozmarín', minutes: 45, score: 'low',
    ingredients: [
      { name: 'Teľacie mäso (čerstvé, plece)', qty: '150 g' },
      { name: 'Zemiaky', qty: '200 g' },
      { name: 'Mrkva', qty: '2 ks' },
      { name: 'Olivový olej', qty: '2 lyž.' },
      { name: 'Rozmarín, čerstvý', qty: '1 vetvička' },
    ],
    steps: [
      'Mäso nakrájaj na kocky, osoľ, peč 25 min na 200 °C.',
      'Zemiaky a mrkvu nakrájaj, peč spolu s rozmarínom.',
      'Pred servírovaním pokvapkaj olejom.',
    ],
    note: 'Teľacie je menej alergénne ako bravčové. Pečenie na sucho neuvoľňuje histamín.',
  },
  'o-jahn': {
    id: 'o-jahn', type: 'Obed', time: '13:00', img: 'chicken',
    title: 'Jahňacie s tekvicou a tymianom',
    sub: 'olivový olej · čerstvý cesnak', minutes: 40, score: 'low',
    ingredients: [
      { name: 'Jahňacie plece (čerstvé)', qty: '140 g' },
      { name: 'Tekvica Hokkaido', qty: '300 g' },
      { name: 'Cesnak', qty: '1 strúčik' },
      { name: 'Tymian, čerstvý', qty: '2 vetvičky' },
      { name: 'Olivový olej', qty: '2 lyž.' },
    ],
    steps: [
      'Tekvicu nakrájaj na kocky, peč na 200 °C 20 min.',
      'Mäso opraž 4 min z každej strany na panvici.',
      'Pridaj cesnak a tymian, peč 8 min.',
      'Spoj s pečenou tekvicou.',
    ],
    note: 'Jahňacie je výborný diverzifikátor proteínu — vyhneš sa stálej rotácii kura/morka.',
  },
  'o-poly': {
    id: 'o-poly', type: 'Obed', time: '13:00', img: 'soup',
    title: 'Kuracia polievka s domácimi rezancami',
    sub: 'mrkva · petržlen · zeler', minutes: 50, score: 'low',
    ingredients: [
      { name: 'Kuracie stehno (čerstvé)', qty: '200 g' },
      { name: 'Mrkva', qty: '2 ks' },
      { name: 'Petržlen koreňový', qty: '1 ks' },
      { name: 'Vajce', qty: '1 ks' },
      { name: 'Špaldová hladká múka', qty: '80 g' },
    ],
    steps: [
      'Kuracie stehno var 30 min s koreňovou zeleninou.',
      'Z vajca a múky vypracuj cesto, nakrájaj na rezance.',
      'Rezance var v polievke 4 min.',
      'Servíruj okamžite, polievku nepoužívaj druhý deň.',
    ],
    note: 'Vývar pripravuj len na 1 deň — uskladnený rýchlo nazbiera histamín. Zmraz prípadne ihneď.',
  },
  'o-pec': {
    id: 'o-pec', type: 'Obed', time: '13:00', img: 'chicken',
    title: 'Pečené kura s pečenou repou',
    sub: 'maslo · tymian · soľ', minutes: 55, score: 'low',
    ingredients: [
      { name: 'Kuracie stehná (čerstvé)', qty: '200 g' },
      { name: 'Cvikla', qty: '2 menšie' },
      { name: 'Maslo', qty: '20 g' },
      { name: 'Tymian, čerstvý', qty: '2 vetvičky' },
    ],
    steps: [
      'Cviklu zabaľ do alobalu, peč 35 min na 200 °C.',
      'Kuracie stehná potri maslom, peč na rošte 30 min.',
      'Servíruj spolu, posyp tymianom.',
    ],
    note: 'Cvikla podporuje detoxifikáciu, je výborná pre histaminikov.',
  },
  'o-ryz': {
    id: 'o-ryz', type: 'Obed', time: '13:00', img: 'rice',
    title: 'Cuketové rizoto s parmezánovou náhradou',
    sub: 'mladá strúhaná ovčia bryndza', minutes: 30, score: 'low',
    ingredients: [
      { name: 'Arborio ryža', qty: '80 g' },
      { name: 'Cuketa', qty: '1 ks' },
      { name: 'Domáci vývar', qty: '500 ml' },
      { name: 'Mladá ovčia bryndza', qty: '30 g' },
      { name: 'Maslo', qty: '20 g' },
    ],
    steps: [
      'Cuketu poduste na masle 3 min.',
      'Pridaj ryžu, postupne prilievaj vývar 18 min.',
      'Pred koncom vmiešaj bryndzu.',
    ],
    note: 'Mladá bryndza (do 7 dní) je v poriadku — vyhni sa zrejúcim a údeným syrom.',
  },

  // ── Snacks ────────────────────────────────────────────────
  's-hrus': {
    id: 's-hrus', type: 'Snack', time: '10:30', img: 'pear',
    title: 'Hruška & čerstvý tvaroh',
    sub: 'akáciový med', minutes: 2, score: 'low',
    ingredients: [
      { name: 'Čerstvý tvaroh (do 24h)', qty: '100 g' },
      { name: 'Hruška', qty: '1 ks' },
      { name: 'Med akáciový', qty: '1 lyž.' },
    ],
    steps: [
      'Tvaroh premiešaj s medom.',
      'Hrušku nakrájaj na plátky, podávaj hneď.',
    ],
    note: 'Iba čerstvý tvaroh s krátkou dobou trvanlivosti.',
  },
  's-ryz': {
    id: 's-ryz', type: 'Snack', time: '16:00', img: 'rice',
    title: 'Ryžové chlebíky & kozí syr',
    sub: 'uhorka · olivový olej', minutes: 3, score: 'low',
    ingredients: [
      { name: 'Ryžové chlebíky', qty: '2 ks' },
      { name: 'Čerstvý kozí syr (mladý)', qty: '40 g' },
      { name: 'Uhorka', qty: '½ ks' },
    ],
    steps: [
      'Chlebíky natri kozím syrom.',
      'Navrch uhorka, pokvapkaj olivovým olejom.',
    ],
    note: 'Iba mladý, nezrejúci kozí syr.',
  },
  's-mand': {
    id: 's-mand', type: 'Snack', time: '10:30', img: 'pear',
    title: 'Mandle & čerstvé jablko',
    sub: 'štipka morskej soli', minutes: 1, score: 'low',
    ingredients: [
      { name: 'Mandle (čerstvé, nesolené)', qty: '20 g' },
      { name: 'Jablko', qty: '1 ks' },
    ],
    steps: ['Jablko nakrájaj na plátky, podávaj s mandľami.'],
    note: 'Mandle z dôveryhodnej značky — staré orechy obsahujú plesne uvoľňujúce histamín.',
  },
  's-smt': {
    id: 's-smt', type: 'Snack', time: '16:00', img: 'pear',
    title: 'Mango-čučoriedkové smoothie',
    sub: 'ryžový nápoj · čerstvé bobule', minutes: 4, score: 'low',
    ingredients: [
      { name: 'Mango', qty: '½ ks' },
      { name: 'Čučoriedky', qty: '50 g' },
      { name: 'Ryžový nápoj', qty: '200 ml' },
      { name: 'Med', qty: '½ lyž.' },
    ],
    steps: [
      'Všetko rozmixuj do hladka.',
      'Pi do 15 minút po pripravení.',
    ],
    note: 'Smoothie sa neuchováva — biogénne amíny rastú rýchlo.',
  },
  's-mrk': {
    id: 's-mrk', type: 'Snack', time: '10:30', img: 'pear',
    title: 'Mrkvové tyčinky & maslo z mandlí',
    sub: 'morská soľ', minutes: 3, score: 'low',
    ingredients: [
      { name: 'Mrkva', qty: '2 ks' },
      { name: 'Mandľové maslo (čerstvo otvorené)', qty: '2 lyž.' },
    ],
    steps: ['Mrkvu nakrájaj na tyčinky, maslo do misky.'],
    note: 'Mandľové maslo z otvoreného pohára spotrebuj do 7 dní v chladničke.',
  },
  's-mel': {
    id: 's-mel', type: 'Snack', time: '16:00', img: 'pear',
    title: 'Melón & čerstvá mäta',
    sub: 'cukrový melón · vodný melón', minutes: 2, score: 'low',
    ingredients: [
      { name: 'Cukrový melón (zrelý)', qty: '200 g' },
      { name: 'Čerstvá mäta', qty: '5 lístkov' },
    ],
    steps: ['Melón nakrájaj na kocky, posyp mätou.'],
    note: 'Iba zrelý melón — zaznamenané prípady reakcie na nezrelý.',
  },
  's-mlad': {
    id: 's-mlad', type: 'Snack', time: '10:30', img: 'pear',
    title: 'Mozzarella „do 24h" & ríbezľa',
    sub: 'olivový olej · bazalka', minutes: 3, score: 'low',
    ingredients: [
      { name: 'Mozzarella (vyrobená do 24h)', qty: '60 g' },
      { name: 'Červené ríbezle', qty: '30 g' },
      { name: 'Bazalka', qty: '4 lístky' },
    ],
    steps: ['Mozzarellu nakrájaj, doplň ríbezľami a bazalkou.'],
    note: 'Mozzarella sa znáša len úplne čerstvá — pýtaj sa pri syrárovi na dátum výroby.',
  },

  // ── Večere ────────────────────────────────────────────────
  'v-tek': {
    id: 'v-tek', type: 'Večera', time: '19:00', img: 'soup',
    title: 'Tekvicový krém s pečenou repou',
    sub: 'zázvor · semienka', minutes: 35, score: 'low',
    ingredients: [
      { name: 'Tekvica Hokkaido', qty: '400 g' },
      { name: 'Cvikla, malá', qty: '1 ks' },
      { name: 'Zázvor, čerstvý', qty: '2 cm' },
      { name: 'Domáci vývar', qty: '500 ml' },
      { name: 'Tekvicové semienka', qty: '1 lyž.' },
    ],
    steps: [
      'Cviklu zabaľ do alobalu, peč 30 min na 200 °C.',
      'Tekvicu opraž v hrnci s olejom, pridaj zázvor.',
      'Zalej vývarom, var 15 min.',
      'Rozmixuj, ozdob repou a semienkami.',
    ],
    note: 'Vývar variť čerstvý — neuchovávať dlhšie ako 24h.',
  },
  'v-brok': {
    id: 'v-brok', type: 'Večera', time: '19:00', img: 'soup',
    title: 'Brokolicový krém s mandľami',
    sub: 'olivový olej · cesnak', minutes: 25, score: 'low',
    ingredients: [
      { name: 'Brokolica', qty: '400 g' },
      { name: 'Zemiak', qty: '1 ks' },
      { name: 'Cesnak', qty: '1 strúčik' },
      { name: 'Domáci vývar', qty: '500 ml' },
      { name: 'Plátkové mandle', qty: '20 g' },
    ],
    steps: [
      'Zeleninu var v osolenej vode 12 min.',
      'Rozmixuj, dochuť cesnakom.',
      'Posyp opraženými mandľami.',
    ],
    note: 'Brokolica obsahuje quercetín — prirodzene tlmí histamín.',
  },
  'v-mrk': {
    id: 'v-mrk', type: 'Večera', time: '19:00', img: 'soup',
    title: 'Mrkvovo-zázvorová polievka',
    sub: 'kokosové mlieko · koriander', minutes: 30, score: 'low',
    ingredients: [
      { name: 'Mrkva', qty: '500 g' },
      { name: 'Zázvor, čerstvý', qty: '3 cm' },
      { name: 'Kokosové mlieko (čerstvé)', qty: '150 ml' },
      { name: 'Domáci vývar', qty: '400 ml' },
      { name: 'Čerstvý koriander', qty: 'hrsť' },
    ],
    steps: [
      'Mrkvu nakrájaj, var s vývarom 20 min.',
      'Pridaj zázvor a kokosové mlieko.',
      'Rozmixuj, ozdob koriandrom.',
    ],
    note: 'Kombinácia zázvor + koriander má prirodzený antihistamínový efekt.',
  },
  'v-quin': {
    id: 'v-quin', type: 'Večera', time: '19:00', img: 'rice',
    title: 'Quinoa s pečenou cuketou a tekvicovými semienkami',
    sub: 'olivový olej · čerstvý petržlen', minutes: 30, score: 'low',
    ingredients: [
      { name: 'Quinoa', qty: '80 g' },
      { name: 'Cuketa', qty: '1 ks' },
      { name: 'Tekvicové semienka', qty: '2 lyž.' },
      { name: 'Olivový olej', qty: '2 lyž.' },
      { name: 'Petržlen', qty: 'hrsť' },
    ],
    steps: [
      'Quinou uvar 15 min.',
      'Cuketu nakrájaj, peč na 200 °C 18 min.',
      'Spoj, posyp semienkami a petržlenom.',
    ],
    note: 'Ľahká večera bez mäsa — telu dáva noc na regeneráciu.',
  },
  'v-tel': {
    id: 'v-tel', type: 'Večera', time: '19:00', img: 'chicken',
    title: 'Dusené teľacie s mrkvou a ryžou',
    sub: 'olej · čerstvý petržlen', minutes: 40, score: 'low',
    ingredients: [
      { name: 'Teľacie (čerstvé)', qty: '120 g' },
      { name: 'Mrkva', qty: '2 ks' },
      { name: 'Basmati ryža', qty: '60 g' },
      { name: 'Olivový olej', qty: '2 lyž.' },
    ],
    steps: [
      'Teľacie nakrájaj na kocky, krátko opraž.',
      'Pridaj mrkvu, podliej vodou, duste 30 min.',
      'Ryžu uvar oddelene, spoj na tanieri.',
    ],
    note: 'Dusenie pod pokrievkou — bez prepáľovania, aby mäso nestrácalo šťavy.',
  },
  'v-ryz': {
    id: 'v-ryz', type: 'Večera', time: '19:00', img: 'rice',
    title: 'Rizoto s cviklou a kozím syrom',
    sub: 'mladý kozí · maslo', minutes: 35, score: 'low',
    ingredients: [
      { name: 'Arborio ryža', qty: '80 g' },
      { name: 'Cvikla', qty: '1 ks (predpečená)' },
      { name: 'Domáci vývar', qty: '500 ml' },
      { name: 'Mladý kozí syr', qty: '30 g' },
      { name: 'Maslo', qty: '20 g' },
    ],
    steps: [
      'Cviklu nakrájaj na kocky.',
      'Ryžu maslo opraž, postupne prilievaj vývar 18 min.',
      'Vmiešaj cviklu a kozí syr.',
    ],
    note: 'Rizoto je pekne sviežo ružové — vizuálne aj nutrične atraktívna večera.',
  },
  'v-bat': {
    id: 'v-bat', type: 'Večera', time: '19:00', img: 'chicken',
    title: 'Pečený batát s kuracím morčacím a špargľou',
    sub: 'olivový olej · čerstvý petržlen', minutes: 38, score: 'low',
    ingredients: [
      { name: 'Batát', qty: '1 menší' },
      { name: 'Morčacie prsia (čerstvé)', qty: '120 g' },
      { name: 'Špargľa', qty: '6 stoniek' },
      { name: 'Olivový olej', qty: '2 lyž.' },
    ],
    steps: [
      'Batát peč v šupke 30 min na 200 °C.',
      'Morčacie a špargľu opraž 6 min na olivovom oleji.',
      'Servíruj spolu, posyp petržlenom.',
    ],
    note: 'Špargľa pôsobí močopudne a podporuje detoxifikáciu — výborná pre histaminikov.',
  },
};

// ─────────────────────────────────────────────────────────────
// Week plan — 7 days
// ─────────────────────────────────────────────────────────────
const WEEK_PLAN = [
  { day: 'Po', label: 'Pondelok', date: '25', mealIds: ['r-quin', 's-mand', 'o-mor', 's-ryz',  'v-brok'] },
  { day: 'Ut', label: 'Utorok',   date: '26', mealIds: ['r-omel', 's-mrk',  'o-tela', 's-smt',  'v-quin'] },
  { day: 'St', label: 'Streda',   date: '27', mealIds: ['r-ovs',  's-hrus', 'o-kura', 's-ryz',  'v-tek']  },
  { day: 'Št', label: 'Štvrtok',  date: '28', mealIds: ['r-ryza', 's-mand', 'o-pec',  's-mel',  'v-mrk']  },
  { day: 'Pi', label: 'Piatok',   date: '29', mealIds: ['r-poh',  's-mlad', 'o-jahn', 's-smt',  'v-ryz']  },
  { day: 'So', label: 'Sobota',   date: '30', mealIds: ['r-kuk',  's-mrk',  'o-ryz',  's-hrus', 'v-bat']  },
  { day: 'Ne', label: 'Nedeľa',   date: '31', mealIds: ['r-aman', 's-mel',  'o-poly', 's-mand', 'v-tel']  },
];

// Resolve ids → full meal objects for each day
const WEEK_MEALS = WEEK_PLAN.map(d => ({
  ...d,
  meals: d.mealIds.map(id => MEALS[id]),
}));

const TODAY_INDEX = 2; // Streda
const TODAY_MEALS = WEEK_MEALS[TODAY_INDEX].meals;

const SUPPLEMENTS = [
  { id: 'dao', name: 'DAO enzým (HITIMUN)', dose: '1 kaps.', when: '15 min pred jedlom', times: ['8:00', '13:00', '19:00'], color: '#8a9a7e' },
  { id: 'c', name: 'Vitamín C', dose: '1000 mg', when: 'rozdelene cez deň', times: ['8:30', '16:00'], color: '#c7a98b' },
  { id: 'b6', name: 'Vitamín B6 (P5P)', dose: '50 mg', when: 'k raňajkam', times: ['8:30'], color: '#b8745a' },
  { id: 'q', name: 'Kvercetín', dose: '500 mg', when: 'k obedu', times: ['13:30'], color: '#5f6f55' },
];

const SYMPTOMS = [
  { id: 'head', label: 'Bolesť hlavy / migréna' },
  { id: 'bloat', label: 'Nafukovanie, kŕče' },
  { id: 'diar', label: 'Hnačka' },
  { id: 'skin', label: 'Vyrážka / svrbenie / akné' },
  { id: 'flush', label: 'Začervenanie kože' },
  { id: 'heart', label: 'Búšenie srdca' },
  { id: 'nose', label: 'Upchatý nos / kýchanie' },
  { id: 'breath', label: 'Ťažké dýchanie' },
  { id: 'dizzy', label: 'Závrat' },
  { id: 'fatigue', label: 'Únava' },
  { id: 'sleep', label: 'Problém so spánkom' },
  { id: 'mood', label: 'Úzkosť' },
];

// ─────────────────────────────────────────────────────────────
// SIGHI tolerance scale (Swiss Interest Group Histamine Intolerance)
// Zdroj: Zoznam znášanlivosti potravín, SIGHI 2016 (preklad OZ Histaminici)
// ─────────────────────────────────────────────────────────────
const SIGHI_SCALE = [
  { score: 0, label: 'Dobre tolerované', desc: 'Pri bežnom užívaní žiadne predpokladané symptómy.', color: '#5f6f55', soft: 'rgba(95,111,85,0.14)' },
  { score: 1, label: 'Stredne kompatibilné', desc: 'Mierne symptómy; malé množstvá sú často tolerované.', color: '#8a9a7e', soft: 'rgba(138,154,126,0.16)' },
  { score: 2, label: 'Nevhodné', desc: 'Viditeľné symptómy pri bežnom príjme.', color: '#c7a98b', soft: 'rgba(199,169,139,0.2)' },
  { score: 3, label: 'Veľmi zle tolerované', desc: 'Mnohé symptómy.', color: '#b8745a', soft: 'rgba(184,116,90,0.16)' },
];

// Dôvody nekompatibility (markery SIGHI)
const MARKERS = {
  'H!': { label: 'Rýchlo podlieha skaze', desc: 'Rýchla tvorba histamínu — jedz len úplne čerstvé.' },
  'H':  { label: 'Vysoký histamín', desc: 'Vysoký obsah histamínu.' },
  'A':  { label: 'Iné amíny', desc: 'Obsah ostatných biogénnych amínov.' },
  'L':  { label: 'Liberátor', desc: 'Uvoľňuje histamín z mastocytov (žírnych buniek).' },
  'B':  { label: 'Blokátor DAO', desc: 'Inhibuje diaminooxidázu alebo iné enzýmy štiepiace histamín.' },
};

// ─────────────────────────────────────────────────────────────
// Food library with SIGHI scores + reason markers
// Skóre podľa SIGHI; výber potravín doplnený z Rady pre pacientov (HITIMUN).
// ─────────────────────────────────────────────────────────────
const FOODS = {
  allowed: [
    { cat: 'Mäso & vajcia', items: [
      { name: 'Morčacie (čerstvé)', score: 0 },
      { name: 'Bravčové (čerstvé)', score: 0 },
      { name: 'Hovädzie (čerstvé)', score: 1, marks: ['H!'] },
      { name: 'Teľacie (čerstvé)', score: 0, marks: ['H!'] },
      { name: 'Jahňacie (čerstvé)', score: 1, marks: ['H!'] },
      { name: 'Divina (čerstvá)', score: 0 },
      { name: 'Kuracie (len úplne čerstvé)', score: 1, marks: ['H!'] },
      { name: 'Vaječný žĺtok', score: 0 },
      { name: 'Prepeličie vajcia', score: 0 },
      { name: 'Vajce varené', score: 1, marks: ['L'] },
    ]},
    { cat: 'Obilniny & príloha', items: [
      { name: 'Ryža (basmati, jasmínová)', score: 0 },
      { name: 'Zemiaky', score: 0 },
      { name: 'Cestoviny (bez vajec)', score: 0 },
      { name: 'Ovsené vločky', score: 0 },
      { name: 'Quinoa', score: 0 },
      { name: 'Pohánka', score: 0 },
      { name: 'Kukuričná múka / polenta', score: 0 },
      { name: 'Amarant', score: 0 },
      { name: 'Špaldová / pšeničná múka', score: 1 },
    ]},
    { cat: 'Zelenina', items: [
      { name: 'Cuketa', score: 0 },
      { name: 'Mrkva', score: 0 },
      { name: 'Karfiol', score: 0 },
      { name: 'Brokolica', score: 1 },
      { name: 'Tekvica', score: 0 },
      { name: 'Cvikla', score: 0 },
      { name: 'Uhorka', score: 0 },
      { name: 'Hlávkový šalát', score: 0 },
      { name: 'Čakanka', score: 0 },
      { name: 'Cesnak', score: 0 },
      { name: 'Cibuľa', score: 0 },
      { name: 'Špargľa', score: 1 },
      { name: 'Reďkovka', score: 0 },
      { name: 'Rebarbora', score: 1, marks: ['L'] },
      { name: 'Batát', score: 0 },
      { name: 'Rukola', score: 0 },
    ]},
    { cat: 'Ovocie', items: [
      { name: 'Jablko', score: 0 },
      { name: 'Hruška', score: 0 },
      { name: 'Čučoriedky', score: 1 },
      { name: 'Marhuľa', score: 1 },
      { name: 'Broskyňa / nektárinka', score: 1 },
      { name: 'Čerešne', score: 1 },
      { name: 'Mango', score: 1 },
      { name: 'Melón', score: 0 },
      { name: 'Granátové jablko', score: 1 },
      { name: 'Egreš', score: 1 },
      { name: 'Brusnice', score: 1 },
      { name: 'Čerstvé figy', score: 1 },
    ]},
    { cat: 'Mliečne (čerstvé)', items: [
      { name: 'Čerstvý tvaroh', score: 1, marks: ['H!'] },
      { name: 'Smotana (čistá)', score: 1, marks: ['H!'] },
      { name: 'Cmar', score: 1, marks: ['H!'] },
      { name: 'Maslo (čerstvé)', score: 0 },
      { name: 'Mladý kozí syr', score: 1, marks: ['H!'] },
      { name: 'Mozzarella (do 24h)', score: 1, marks: ['H!'] },
      { name: 'Ricotta (čerstvá)', score: 1, marks: ['H!'] },
    ]},
    { cat: 'Tuky & ostatné', items: [
      { name: 'Olivový olej', score: 0 },
      { name: 'Rastlinný olej', score: 0 },
      { name: 'Mandle (čerstvé)', score: 1 },
      { name: 'Tekvicové semienka', score: 0 },
      { name: 'Med', score: 0 },
      { name: 'Javorový sirup', score: 0 },
      { name: 'Ryžový / mandľový nápoj', score: 0 },
      { name: 'Bylinkové čaje', score: 0 },
      { name: 'Voda, nesýtená minerálka', score: 0 },
      { name: 'Čerstvé bylinky', score: 0 },
    ]},
  ],
  avoid: [
    { cat: 'Vysoký histamín', items: [
      { name: 'Zrejúce a plesnivé syry (gouda, čedar, niva)', score: 3, marks: ['H'] },
      { name: 'Údeniny (saláma, šunka)', score: 3, marks: ['H', 'A'] },
      { name: 'Mleté a skladované mäso', score: 3, marks: ['H!', 'H'] },
      { name: 'Ryby a morské plody (nie čerstvé)', score: 3, marks: ['H!', 'H'] },
      { name: 'Paradajky', score: 3, marks: ['H', 'L'] },
      { name: 'Špenát', score: 3, marks: ['H'] },
      { name: 'Baklažán', score: 2, marks: ['H'] },
      { name: 'Avokádo', score: 2, marks: ['H', 'A'] },
      { name: 'Strukoviny', score: 2, marks: ['A'] },
    ]},
    { cat: 'Liberátory histamínu', items: [
      { name: 'Jahody & bobuľové ovocie', score: 2, marks: ['L'] },
      { name: 'Ananás', score: 2, marks: ['L'] },
      { name: 'Banán', score: 2, marks: ['L', 'A'] },
      { name: 'Kiwi', score: 2, marks: ['L'] },
      { name: 'Papája', score: 2, marks: ['L'] },
      { name: 'Citrusy', score: 2, marks: ['L'] },
      { name: 'Čokoláda & kakao', score: 3, marks: ['L', 'B'] },
      { name: 'Orechy (vlašské, kešu, búrske)', score: 2, marks: ['L'] },
      { name: 'Surový vaječný bielok', score: 2, marks: ['L'] },
      { name: 'Koreniny (štipľavé)', score: 2, marks: ['L'] },
    ]},
    { cat: 'Kvasené & fermentované', items: [
      { name: 'Kyslá kapusta', score: 3, marks: ['H'] },
      { name: 'Ocot & nakladané potraviny', score: 3, marks: ['H'] },
      { name: 'Jogurt, kefír', score: 2, marks: ['H'] },
      { name: 'Kombucha', score: 3, marks: ['H'] },
      { name: 'Sója a sójová omáčka', score: 3, marks: ['H', 'B'] },
      { name: 'Tofu (fermentované)', score: 2, marks: ['H'] },
      { name: 'Kysnuté cesto, čerstvý kvasnicový chlieb', score: 2, marks: ['H'] },
    ]},
    { cat: 'Nápoje & aditíva', items: [
      { name: 'Červené víno, sekt', score: 3, marks: ['H', 'B'] },
      { name: 'Kvasnicové pivo', score: 3, marks: ['H', 'B'] },
      { name: 'Destiláty / alkohol', score: 3, marks: ['B'] },
      { name: 'Čierny & zelený čaj', score: 2, marks: ['B'] },
      { name: 'Sýtené nápoje', score: 2 },
      { name: 'Glutamát (zvýrazňovače chuti)', score: 2, marks: ['L'] },
      { name: 'Konzervanty, farbivá, príchute', score: 2, marks: ['L'] },
      { name: 'Sladké drievko', score: 2, marks: ['L'] },
    ]},
  ],
};

// ─────────────────────────────────────────────────────────────
// Zásady nízkohistamínovej diéty (Rady pre pacientov, HITIMUN 2023)
// ─────────────────────────────────────────────────────────────
const PRINCIPLES = [
  { icon: 'fresh', title: 'Jedz len čerstvé potraviny', body: 'Sleduj dátum spotreby. Čerstvosť je pri histamíne dôležitejšia než čokoľvek iné.' },
  { icon: 'store', title: 'Neskladuj a neprihrievaj varené jedlo', body: 'Histamín sa varom nerozkladá — v chladničke môže narásť až 10-násobne. Var len toľko, koľko zješ.' },
  { icon: 'can', title: 'Vyhni sa konzervám a mrazenej strave', body: 'Čím dlhšie je potravina uskladnená, tým viac histamínu obsahuje — aj zmrazená.' },
  { icon: 'ferment', title: 'Žiadna fermentácia ani kvasenie', body: 'Kvasené a vyzreté potraviny patria medzi najsilnejšie zdroje histamínu.' },
  { icon: 'home', title: 'Uprednostni domácu stravu', body: 'Máš kontrolu nad zložením aj čerstvosťou surovín. Čítaj zoznam zložiek na obaloch.' },
  { icon: 'alcohol', title: 'Obmedz alkohol', body: 'Víno, sekt a pivo obsahujú histamín; destiláty blokujú enzým DAO.' },
  { icon: 'identify', title: 'Identifikuj svoje spúšťače', body: 'Tolerancia je individuálna a závisí od dávky. Nájdi mieru, ktorú telo zvládne, aby si sa zbytočne neobmedzovala.' },
];

// DAO doplnok — presné info z príbalového letáku HITIMUN DAO
const DAO_INFO = {
  product: 'HITIMUN® DAO',
  enzyme: 'diaminooxidáza (DAOgest®)',
  activity: '36 000 HDU / kapsula',
  dose: '1 kapsula 15 min pred jedlom s histamínom',
  max: 'max. 3 kapsuly denne (3 jedlá s histamínom)',
  drink: 'zapiť malým množstvom vody',
  free: 'bez gluténu, laktózy, fruktózy aj histamínu',
};

// Lieky, ktoré môžu zhoršovať príznaky (uvoľňovače / blokátory DAO)
const TRIGGER_MEDS = [
  'Niektoré antibiotiká (kyselina klavulanová, doxycyklín, isoniazid)',
  'Analgetiká (metamizol, kyselina acetylsalicylová, morfín, kodeín)',
  'Antidepresíva a psychofarmaká (amitriptylín, diazepam, IMAO)',
  'Antihypertenzíva (verapamil, alprenolol, dihydralazín)',
  'Mukolytiká (N-acetylcysteín, ambroxol)',
  'Diuretiká (furosemid, amilorid)',
  'Kontrastné látky (najmä s jódom)',
  'Lokálne anestetiká (prokaín, prilokaín)',
];

Object.assign(window, {
  MEALS, WEEK_PLAN, WEEK_MEALS, TODAY_INDEX, TODAY_MEALS,
  SUPPLEMENTS, SYMPTOMS, FOODS,
  SIGHI_SCALE, MARKERS, PRINCIPLES, DAO_INFO, TRIGGER_MEDS,
});
